#include "calc.h"
 
int ans;
 
void add(int a,int b){
    ans = a + b;
}
 
void sub(int a,int b){
    ans = a - b;
}
