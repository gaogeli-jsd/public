#ifndef _CALC_H_
#define _CALC_H_
 
void add(int,int);
void sub(int,int);
 
#endif // _CALC_H_
