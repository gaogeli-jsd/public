#ifndef _SHOW_RESULT_H_
#define _SHOW_RESULT_H_
 
void showAnswer();
 
#endif // _SHOW_RESULT_H_
