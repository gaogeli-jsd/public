#include "showResult.h"
#include <stdio.h>
 
extern int ans;
 
void showAnswer(){
    printf("%d\n",ans);
}
