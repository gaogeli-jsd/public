#include <stdio.h>
 
void main(){
    printf("HelloWorld.");
}